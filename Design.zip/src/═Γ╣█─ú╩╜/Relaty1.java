package 外观模式;
public class Relaty1
{
    public void sell()
    {
        System.out.println("房地产1卖出");
    }

    public void buy()
    {
        System.out.println("房地产1买入");
    }
}

