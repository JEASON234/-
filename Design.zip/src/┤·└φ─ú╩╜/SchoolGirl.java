package 代理模式;

public class SchoolGirl {
    public String	name;

    public String getName() {

        return name;
    }

    public void setName(String name) {

        this.name = name;
    }

}
