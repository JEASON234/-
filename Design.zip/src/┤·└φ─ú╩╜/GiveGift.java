package 代理模式;
public interface GiveGift {

    void giveRose();

    void giveNecklace();

    void giveRings();

    void givePiano();
}
