package 代理模式;

public class Main {
    public static void main(String[]args){

        SchoolGirl Jennie = new SchoolGirl();
        Jennie.setName("Jennie");
        SchoolGirl Rose = new SchoolGirl();
        Rose.setName("Rose");
        SchoolGirl Lisa = new SchoolGirl();
        Lisa.setName("Lisa");
        SchoolGirl Jisoo = new SchoolGirl();
        Jisoo.setName("Jisoo");


        Proxy daili1 = new Proxy(Jennie);
        daili1.giveNecklace();
        Proxy daili2 = new Proxy(Rose);
        daili2.givePiano();
        Proxy daili3 = new Proxy(Lisa);
        daili3.giveRose();
        Proxy daili4 = new Proxy(Jisoo);
        daili4.giveRings();
    }


}
