package 建造者模式;

public interface Drinks {
    public  void produce();
}
