package 建造者模式;


public interface Food {
    public  void produce();
}
