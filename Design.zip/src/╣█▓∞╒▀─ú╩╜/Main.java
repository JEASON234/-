package 观察者模式;

public class Main {

    public static void main(String[] args) {

        Boss GY = new Boss();

        ProgramObserver tongshi1 = new ProgramObserver("GEM", GY);
        GY.attach(tongshi1);
        SongObserver tongshi2 = new SongObserver("Jay", GY);
        GY.attach(tongshi2);

        GY.setAction("华语歌手：");
        GY.announce();

    }
}
