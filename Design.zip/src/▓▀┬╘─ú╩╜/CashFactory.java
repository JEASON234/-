package 策略模式;
public class CashFactory {
    public static CashSuper createCash(String type)
    {
        CashSuper cs = null;
        if ("正常价位".equals(type))
        {
            cs = new CashNormal();
        }
        else if ("满688返100".equals(type))
        {
            cs = new CashReturn(688, 100);
        }
        else if ("打七五折".equals(type))
        {
            cs = new CashRebate(0.75);
        }

        return cs;
    }
}
