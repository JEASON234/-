package 策略模式;
public interface CashSuper {
    public double acceptCash(double money);
}
