package 装饰者模式;

public class shorts extends Finery {
    public void show()
    {
        super.show();
        System.out.println("牛仔短裤");
    }
}
