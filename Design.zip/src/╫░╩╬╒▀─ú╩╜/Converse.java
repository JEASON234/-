package 装饰者模式;

public class Converse extends Finery {
    public void show()
    {
        super.show();
        System.out.println("匡威帆布鞋");
    }
}
