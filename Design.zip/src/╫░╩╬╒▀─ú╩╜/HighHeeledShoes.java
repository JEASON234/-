package 装饰者模式;

public class HighHeeledShoes extends Finery {
    public void show()
    {
        super.show();
        System.out.println("高跟鞋");
    }
}
