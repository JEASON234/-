package 装饰者模式;

public class FormalDress extends Finery {
    public void show()
    {
        super.show();
        System.out.println("晚礼服");
    }
}
