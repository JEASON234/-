package 装饰者模式;

public class BM extends Finery {
    public void show()
    {
        super.show();
        System.out.println("修身短袖");
    }
}
