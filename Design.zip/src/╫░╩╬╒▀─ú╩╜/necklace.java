package 装饰者模式;

public class necklace extends Finery {
    public void show()
    {
        super.show();
        System.out.println("珍珠项链");
    }
}
