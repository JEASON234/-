package 工厂方法模式;
public class SimpleFactory {
    public static LeiFeng createLeiFeng(String type)
    {
        LeiFeng result = null;

        if ("社区志愿者".equals(type))
        {
            result = new Undergraduate();
        }
        else if ("学雷锋的大学生".equals(type))
        {
            result = new Volunteer();
        }

        return result;
    }
}
