package 工厂方法模式;
public class LeiFeng {
    public void MakeDumplings()
    {
        System.out.println("包饺子");
    }

    public void sweep()
    {
        System.out.println("打扫卫生");
    }

    public void wish()
    {
        System.out.println("洗衣服");
    }
}
