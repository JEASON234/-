package 工厂方法模式;
public class Main {
    public static void main(String[]args){
        LeiFeng VolunteerA = SimpleFactory.createLeiFeng("社区志愿者");
        VolunteerA.MakeDumplings();

        LeiFeng VolunteerB = SimpleFactory.createLeiFeng("社区志愿者");
        VolunteerB.sweep();

        LeiFeng VolunteerC = SimpleFactory.createLeiFeng("社区志愿者");
        VolunteerC.wish();

      
    }



}
