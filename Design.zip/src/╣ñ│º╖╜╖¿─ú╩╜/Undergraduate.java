package 工厂方法模式;
public class Undergraduate extends LeiFeng{
    public LeiFeng createLeiFeng()
    {
        return new Undergraduate();
    }

}
